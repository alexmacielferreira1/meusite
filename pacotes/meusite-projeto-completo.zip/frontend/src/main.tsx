import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";
import { installErrorReport } from "./lib/errorReport";

installErrorReport();

createRoot(document.getElementById("root")!).render(<StrictMode><App /></StrictMode>);
